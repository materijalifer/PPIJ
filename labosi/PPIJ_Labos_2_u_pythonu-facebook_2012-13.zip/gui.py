# -*- coding: utf-8 -*-
import easygui as eq
import novi
import webbrowser
from settings import *
import uuid

state = str(uuid.uuid1())
uk = auth_url + app_id + "&redirect_uri=" + redirect_uri +"&state="+state+"&scope="+"publish_stream,read_stream"

def login():
    webbrowser.open(uk)
    sifra = eq.enterbox("Unesite dobiveni url.","Unos url-a.")
    sifra = sifra.split("access_token=")
    sifra = sifra[1].split("&expires_in=")
    token = sifra[0]
    return token

def izlistaj(korisnik):
    zid = novi.dohvati_postove(korisnik)
    test = []
    for t in zid:
        if 'message' in t:
            test.append(("Post:"+t['id']+"         Od: "+t['from']['name']+ '       Poruka:' + t['message']).encode("utf-8"))
    post = eq.choicebox('Odaberite jedan od postova.','Postovi na zidu',test)
    if post == None:
        return 'Gotovo'
    else:
        while(1):
            kraj = listaj_komentare(post)
            if kraj == 'Gotovo':
                break
            
def listaj_komentare(post):
    polje=[]
    trebam = post
    trebam=trebam.lstrip("Post:")
    trebam=trebam.replace(" ","")
    trebam = trebam.partition("O")
    trebam=trebam[0]
    komentari = novi.dohvati_komentare(korisnik,trebam)
    if 'comments' in komentari:
        for t in komentari['comments']['data']:
            if 'message' in t:
                polje.append(("Post:"+t['id']+"         Od: "+t['from']['name']+ '       Poruka:' + t['message']).encode("utf-8"))
        izbor = eq.choicebox('Želite li dodati komentar?','Odgovori na komentar',polje)    
    else:
        polje.append('Prazno')
        izbor   = eq.choicebox('Nema komentara na ovaj post, želite li biti prvi?', 'Odgovori na komentar', polje)
    if izbor != None:
        postaj_komentar(korisnik,trebam)
    else:
        return 'Gotovo'
                
def postaj_komentar(korisnik,kamo):   
    tekst = eq.enterbox("Unesite tekst poruke.","Unos poruke")
    if tekst == None or len(tekst) == 0 or len(tekst)>100:
        eq.msgbox("Poruka ne smije biti prazna niti dulja od sto znakova.")
        return
    izbor = eq.buttonbox('Sigurno želite postati?', choices=['Da','Hm... ipak ne'])
    if izbor == 'Da':
        novi.postavi_komentar(korisnik,kamo,tekst)

def postaj_post(korisnik):
    tekst = eq.enterbox("Unesite tekst poruke.","Unos poruke")
    if tekst == None or len(tekst) == 0 or len(tekst)>100:
        eq.msgbox("Poruka ne smije biti prazna niti dulja od sto znakova.")
        return
    izbor = eq.buttonbox('Sigurno želite postati?', choices=['Da','Hm... ipak ne'])
    if izbor == 'Da':
        novi.postavi_post(korisnik,tekst)

def pocetak(korisnik):
    while(1):
        odabir   = eq.buttonbox('Što želite dalje?',choices=['Izlistaj postove','Dodaj post','Završi'])
        if odabir == 'Izlistaj postove':
            while(1):
                if(izlistaj(korisnik)) == 'Gotovo':
                    break
        elif odabir == 'Dodaj post':
            postaj_post(korisnik)
        else:
            break


        
if __name__ == "__main__":
    eq.msgbox("Dobrodošli u PPIJ_super_app!", ok_button="Login")
    token = login()
    korisnik = novi.auth(token)
    ime = novi.tko_je(korisnik).encode("utf-8")
    eq.msgbox("Dobrodošli " + ime + "!", ok_button="Nastavi")
    
    pocetak(korisnik) 
    
