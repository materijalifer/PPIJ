# -*- coding: cp1250 -*-
import facebook
import uuid

def auth(token):    
    try:
        graph = facebook.GraphAPI(token)       
        return graph
    except facebook.GraphAPIError as e:
        print e

def tko_je(graph):
    return graph.get_object('me')['name']

def dohvati_postove(graph):
    stvari = graph.get_object("PPIJFER/feed",limit=1000)
    postovi = stvari['data']
    return postovi

def dohvati_komentare(graph,post):
    komentari = graph.get_object(post)
    return komentari

def postavi_komentar(graph,kamo,tekst):
    graph.put_object(kamo, 'comments', message=tekst)

def postavi_post(graph,tekst):
    graph.put_object('PPIJFER', 'feed', message=tekst)






