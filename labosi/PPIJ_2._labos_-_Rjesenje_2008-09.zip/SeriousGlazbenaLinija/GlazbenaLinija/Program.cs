﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SeriousGlazbenaLinija;
using SeriousGlazbenaLinija.Komponente;
using SeriousGlazbenaLinija.Zvučnici;

namespace GlazbenaLinijaProgram {
	class Program {
		static void Main(string[] args) {
			GlazbenaLinija ozbiljnaLinija = new GlazbenaLinija("Ozbiljna glazbena linija");

			#region komponente
			IKomponenta komponentaRP1 = KomponentaFactory.napraviKomponentu(EKomponenta.RadioPrijemnik);
			IKomponenta komponentaRP2 = KomponentaFactory.napraviKomponentu(EKomponenta.RadioPrijemnik);
			IKomponenta komponentaPojačalo = KomponentaFactory.napraviKomponentu(EKomponenta.Pojačalo);
			IKomponenta komponentaCDPlayer = KomponentaFactory.napraviKomponentu(EKomponenta.CDPlayer);
			
			komponentaRP1.postaviIme("Radio prijemnik #1");
			komponentaRP2.postaviIme("Radio prijemnik #2");
			komponentaPojačalo.postaviIme("Ultra High-End-ali-opet-jeftino Pojačalo");
			komponentaCDPlayer.postaviIme("Fancy CD player");
			
			Console.WriteLine("Spajam komponentu [" + komponentaRP1.GetType() + "] ..");
			ozbiljnaLinija.spojiKomponentu(komponentaRP1);
			
			Console.WriteLine("Spajam komponentu [" + komponentaRP2.GetType() + "] ..");
			ozbiljnaLinija.spojiKomponentu(komponentaRP2);
	
			Console.WriteLine("Spajam komponentu [" + komponentaPojačalo.GetType() + "] ..");
			ozbiljnaLinija.spojiKomponentu(komponentaPojačalo);

			Console.WriteLine("Spajam komponentu [" + komponentaCDPlayer.GetType() + "] ..");
			ozbiljnaLinija.spojiKomponentu(komponentaCDPlayer);

			#endregion

			Console.WriteLine();

			#region zvučnici
			IZvučnik zvučnikKvalitetniLijevi = ZvučnikFactory.napraviZvučnik(EZvučnik.SkupiDvostrukiZvučnik);
			IZvučnik zvučnikKvalitetniDesni = ZvučnikFactory.napraviZvučnik(EZvučnik.SkupiDvostrukiZvučnik);
			IZvučnik zvučnikSubwoofer = ZvučnikFactory.napraviZvučnik(EZvučnik.Subwoofer);

			Console.WriteLine("Spajam zvučnik [" + zvučnikKvalitetniLijevi + "] ..");
			ozbiljnaLinija.spojiZvučnik(zvučnikKvalitetniLijevi);

			Console.WriteLine("Spajam zvučnik [" + zvučnikKvalitetniDesni + "] ..");
			ozbiljnaLinija.spojiZvučnik(zvučnikKvalitetniDesni);

			Console.WriteLine("Spajam zvučnik [" + zvučnikSubwoofer + "] ..");
			ozbiljnaLinija.spojiZvučnik(zvučnikSubwoofer);

			#endregion

			Console.WriteLine();

			#region pritisci gumbiju
			Console.WriteLine("---------------");
			Console.WriteLine("RadioPrijemnik1");
			Console.WriteLine("---------------");
			Console.WriteLine("Stišćem gumb Eject");
			komponentaRP1.pritisniGumb(EGumb.Eject);
			Console.WriteLine("Stišćem gumb On/Off");
			komponentaRP1.pritisniGumb(EGumb.OnOff);
			Console.WriteLine("Stišćem gumb Eject");
			komponentaRP1.pritisniGumb(EGumb.Eject);
			Console.WriteLine("Stišćem gumb Mute");
			komponentaRP1.pritisniGumb(EGumb.Mute);
			Console.WriteLine("Stišćem gumb Mute");
			komponentaRP1.pritisniGumb(EGumb.Mute);

			Console.WriteLine("---------");
			Console.WriteLine("CD Player");
			Console.WriteLine("---------");
			Console.WriteLine("Stišćem gumb On/Off");
			komponentaCDPlayer.pritisniGumb(EGumb.OnOff);
			Console.WriteLine("Stišćem gumb Play");
			komponentaCDPlayer.pritisniGumb(EGumb.Play);
			Console.WriteLine("Stišćem gumb Eject");
			komponentaCDPlayer.pritisniGumb(EGumb.Eject);
			Console.WriteLine("Stišćem gumb Play");
			komponentaCDPlayer.pritisniGumb(EGumb.Play);
			Console.WriteLine("Stišćem gumb Stop");
			komponentaCDPlayer.pritisniGumb(EGumb.Stop);
			Console.WriteLine("Stišćem gumb Eject");
			komponentaCDPlayer.pritisniGumb(EGumb.Eject);
			Console.WriteLine("Stišćem gumb Play");
			komponentaCDPlayer.pritisniGumb(EGumb.Play);

			
			#endregion

			Console.WriteLine();

			#region odspajanje
			Console.WriteLine("Odspajam zvučnike ..");
			ozbiljnaLinija.odspojiZvučnik(zvučnikSubwoofer);
			ozbiljnaLinija.odspojiZvučnik(zvučnikKvalitetniLijevi);
			ozbiljnaLinija.odspojiZvučnik(zvučnikKvalitetniDesni);

			Console.WriteLine("Odspajam komponente.. ");
			ozbiljnaLinija.odspojiKomponentu(komponentaRP1);
			ozbiljnaLinija.odspojiKomponentu(komponentaRP2);
			ozbiljnaLinija.odspojiKomponentu(komponentaPojačalo);
			
			
			#endregion

			Console.ReadLine();
		}
	}
}
