﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SeriousGlazbenaLinija.Komponente;
using SeriousGlazbenaLinija.Zvučnici;

namespace SeriousGlazbenaLinija {
	/// <summary>
	/// Predstavlja glavnu komponentu glazbene linije, na koju su spojene sve ostale komponente.
	/// </summary>
	public class GlazbenaLinija {
		#region svojstva
		private String imeGlazbeneLinije;
		private List<IKomponenta> komponente;
		private Pojačalo pojačalo;

		#endregion

		#region konstruktori
		/// <summary>
		/// Konstruktor glazbene linije.
		/// Radi novu glazbenu liniju.
		/// </summary>
		public GlazbenaLinija() {
			// inicijaliziraj listu komponenata
			komponente = new List<IKomponenta>();

			this.imeGlazbeneLinije = "Glazbena linija";

			Ispisi.Opći.ispiši("Napravljena nova glazbena linija.");
		}

		/// <summary>
		/// Konstruktor glazbene linije.
		/// Radi novu glazbenu liniju sa zadanim imenom.
		/// </summary>
		public GlazbenaLinija(String imeGlazbeneLinije) {
			// inicijaliziraj listu komponenata
			komponente = new List<IKomponenta>();

			this.imeGlazbeneLinije = imeGlazbeneLinije;

			Ispisi.Opći.ispiši("Napravljena nova glazbena linija [" + imeGlazbeneLinije + "].");
		}
		#endregion

		#region komponente - dodavanje
		/// <summary>
		/// Spaja komponentu sa glazbenom linijom.
		/// </summary>
		/// <param name="komponenta">komponenta koju želimo dodati</param>
		/// <returns>je li komponenta uspješno spojena</returns>
		public bool spojiKomponentu(IKomponenta komponenta) {

			// provjeri postoji li već komponenta
			if (komponenta == null || komponente.Contains(komponenta)) {
				return false;
			}

			// ukoliko dodajemo pojačalo, postavi ga kao pojačalo ove GlazbeneLinije
			if (komponenta.GetType().Equals(typeof(Pojačalo))) {
				// provjeri postoji li već pojačalo
				if (this.pojačalo != null) {
					Ispisi.Greška.ispiši("Nije moguće dodati više od jednog pojačala!");
					return false;
				}
				this.pojačalo = (Pojačalo) komponenta;
			}

			komponenta.postaviStanjeNapajanja(true);
			komponente.Add(komponenta);

			
			Ispisi.Opći.ispiši("Uspješno spojena zadana komponenta [" + komponenta.vratiIme() + "] tipa [" + komponenta.GetType() + "].");
			return true;
		}

		#endregion

		#region komponente - odspajanje
		/// <summary>
		/// Odspaja zadanu komponentu.
		/// </summary>
		/// <param name="brojKomponente">komponenta koju želimo odspojiti</param>
		/// <returns>je li komponenta uspješno uklonjena</returns>
		public bool odspojiKomponentu(IKomponenta komponenta) {

			// provjeri postoji li komponenta
			if (komponenta == null || !komponente.Contains(komponenta)) {
				return false;
			}
			// ukoliko skidamo pojačalo, ukloni ga kao pojačalo ove GlazbeneLinije
			if (komponenta.GetType().GetType().Equals(typeof(Pojačalo))) {
				this.pojačalo = null;
			}

			komponenta.postaviStanjeNapajanja(false);
			komponente.Remove(komponenta);

			Ispisi.Opći.ispiši("Uspješno odspojena zadana komponenta [" + komponenta.vratiIme() + "] tipa [" + komponenta.GetType() + "].");
			return true;
		}
		#endregion

		#region dodaje/odspaja zvučnike sa pojačala (ukoliko je ono spojeno)
		/// <summary>
		/// Spaja zvučnik sa pojačalom, ukoliko je pojačalo spojeno
		/// </summary>
		/// <param name="komponenta">zvučnik koji želimo dodati</param>
		/// <returns>je li zvučnik uspješno spojen</returns>
		public bool spojiZvučnik(IZvučnik zvučnik) {

			// provjeri postoje li zvučnik i pojačalo
			if (zvučnik == null || pojačalo == null) {
				return false;
			}
			bool pojačaloSpojeno = pojačalo.spojiZvučnik(zvučnik);
			if (pojačaloSpojeno) {
				Ispisi.Opći.ispiši("Uspješno spojen zadani zvučnik tipa [" + zvučnik.GetType() + "].");
				return true;
			} else {
				Ispisi.Opći.ispiši("Zadani zvučnik tipa [" + zvučnik.GetType() + "] nije bilo moguće spojiti sa pojačalom.");
				return false;
			}
		}

		/// <summary>
		/// Odspaja zvučnik od pojačala, ukoliko je pojačalo spojeno
		/// </summary>
		/// <param name="komponenta">zvučnik koji želimo dodati</param>
		/// <returns>je li zvučnik uspješno spojen</returns>
		public bool odspojiZvučnik(IZvučnik zvučnik) {

			// provjeri postoje li zvučnik i pojačalo
			if (zvučnik == null || pojačalo == null) {
				return false;
			}
			bool pojačaloOdspojeno = pojačalo.odspojiZvučnik(zvučnik);
			if (pojačaloOdspojeno) {
				Ispisi.Opći.ispiši("Uspješno odspojen zadani zvučnik tipa [" + zvučnik.GetType() + "].");
				return true;
			} else {
				Ispisi.Opći.ispiši("Zadani zvučnik tipa [" + zvučnik.GetType() + "] nije bilo moguće odspojiti od pojačala.");
				return false;
			}
		}
		
		#endregion

		#region getteri/setteri imena glazbene linije
		/// <summary>
		/// Postavlja ime ove glazbene linije na zadanu vrijednost.
		/// </summary>
		/// <param name="imeKomponente">zadano ime</param>
		public void postaviIme(String imeGlazbeneLinije) {
			this.imeGlazbeneLinije = imeGlazbeneLinije;
		}

		/// <summary>
		/// Vraća ime ove glazbene linije.
		/// </summary>
		/// <returns>ime ove glazbene linije</returns>
		public String vratiIme() {
			return this.imeGlazbeneLinije;
		}
		#endregion

	}
}
