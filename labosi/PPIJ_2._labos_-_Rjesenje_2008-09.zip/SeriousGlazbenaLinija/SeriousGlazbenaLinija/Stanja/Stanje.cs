﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeriousGlazbenaLinija.Stanja {
	/// <summary>
	/// Trenutno stanje komponente.
	/// Oblikovni obrazac: State
	/// </summary>
	public class Stanje {

		private EStanje stanje;

		/// <summary>
		/// Konstruira novo Stanje sa zadanim početnim stanjem.
		/// </summary>
		/// <param name="stanje">početno stanje ovog Stanja</param>
		public Stanje(EStanje stanje) {
			this.stanje = stanje;
		}

		/// <summary>
		/// Prebacuje stanje u novo stanje.
		/// </summary>
		public void novoStanje(EStanje stanje) {
			this.stanje = stanje;
		}

		
		/// <summary>
		/// Vraća trenutno stanje.
		/// </summary>
		/// <returns>trenutno stanje</returns>
		public EStanje trenutnoStanje() {
			return stanje;
		}
	}
}
