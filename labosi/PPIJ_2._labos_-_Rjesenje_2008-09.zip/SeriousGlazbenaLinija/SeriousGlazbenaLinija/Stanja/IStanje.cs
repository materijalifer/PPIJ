﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeriousGlazbenaLinija.Stanja {
	/// <summary>
	/// Sučelje koje predstavlja jedno stanje komponente.
	/// Oblikovni obrazac: State
	/// </summary>
	public interface IStanje {
		
		/// <summary>
		/// Prebacuje stanje u novo stanje.
		/// </summary>
		void novoStanje(Stanje stanje);

		/// <summary>
		/// Vraća trenutno stanje.
		/// </summary>
		/// <returns>trenutno stanje</returns>
		Stanje vratiStanje();
	}
}
