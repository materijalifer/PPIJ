﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeriousGlazbenaLinija.Stanja {
	/// <summary>
	/// Popis mogućih stanja u kojima može biti neka komponenta.
	/// </summary>
	public enum EStanje {
		StandBy,
		Idle,
		Playing,
		Paused,
		Recording,
		Ejecting,
		Ejected,
		Loading,
		Seeking
	}
}
