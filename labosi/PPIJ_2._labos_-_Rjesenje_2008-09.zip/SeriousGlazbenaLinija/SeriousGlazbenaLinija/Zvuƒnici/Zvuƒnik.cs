﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeriousGlazbenaLinija.Zvučnici {
	public abstract class Zvučnik : IZvučnik {
		protected const bool podržavaLiNiskeFrekvencije = false;
		protected const bool podržavaLiSrednjeFrekvencije = false;
		protected const bool podržavaLiVisokeFrekvencije = false;

		/// <summary>
		/// Podržava li zvučnik niske frekvencije.
		/// </summary>
		/// <returns></returns>
		public bool podržavaNiskeFrekvencije() {
			return podržavaLiNiskeFrekvencije;
		}

		/// <summary>
		/// Podržava li zvučnik srednje frekvencije.
		/// </summary>
		/// <returns></returns>
		public bool podržavaSrednjeFrekvencije() {
			return podržavaLiSrednjeFrekvencije;
		}

		/// <summary>
		/// Podržava li zvučnik visoke frekvencije.
		/// </summary>
		/// <returns></returns>
		public bool podržavaVisokeFrekvencije() {
			return podržavaLiVisokeFrekvencije;
		}

	}
}
