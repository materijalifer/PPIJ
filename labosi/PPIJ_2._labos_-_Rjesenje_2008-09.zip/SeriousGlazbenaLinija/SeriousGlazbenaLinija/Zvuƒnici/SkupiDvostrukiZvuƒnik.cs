﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeriousGlazbenaLinija.Zvučnici {
	/// <summary>
	/// Skupi zvučnik koji reproducira srednje i visoke frekvencije.
	/// </summary>
	class SkupiDvostrukiZvučnik : Zvučnik {
		new private const bool podržavaLiNiskeFrekvencije = false;
		new private const bool podržavaLiSrednjeFrekvencije = true;
		new private const bool podržavaLiVisokeFrekvencije = true;

	}
}
