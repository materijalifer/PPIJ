﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeriousGlazbenaLinija.Zvučnici {
	/// <summary>
	/// Omogućuje izradu novih objekata klase koja implementira
	/// <see cref="IZvučnik"/> sučelje.
	/// Oblikovni obrazac: Factory
	/// </summary>
	public static class ZvučnikFactory {

		public static IZvučnik napraviZvučnik(EZvučnik tipZvučnika) {
			switch (tipZvučnika) {
				case EZvučnik.JeftiniGeneričkiZvučnik:
					return new JeftiniGeneričkiZvučnik();
				case EZvučnik.SkupiDvostrukiZvučnik:
					return new SkupiDvostrukiZvučnik();
				case EZvučnik.SkupiGeneričkiZvučnik:
					return new SkupiGeneričkiZvučnik();
				case EZvučnik.Subwoofer:
					return new Subwoofer();
				case EZvučnik.Tweeter:
					return new Tweeter();
				default:
					throw new Exceptioni.NepostojećiTipZvučnikaException();
			}
		}

	}
}
