﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeriousGlazbenaLinija.Zvučnici {
	/// <summary>
	/// Jeftini generički zvučnik koji podržava samo srednje frekvencije.
	/// </summary>
	class JeftiniGeneričkiZvučnik : Zvučnik {
		new private const bool podržavaLiNiskeFrekvencije = false;
		new private const bool podržavaLiSrednjeFrekvencije = true;
		new private const bool podržavaLiVisokeFrekvencije = false;

	}

}

