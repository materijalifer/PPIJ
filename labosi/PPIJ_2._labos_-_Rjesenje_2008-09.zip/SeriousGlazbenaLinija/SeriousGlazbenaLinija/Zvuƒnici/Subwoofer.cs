﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeriousGlazbenaLinija.Zvučnici {
	/// <summary>
	/// Subwoofer, podržava samo niske frekvencije.
	/// </summary>
	class Subwoofer : Zvučnik {
		new private const bool podržavaLiNiskeFrekvencije = true;
		new private const bool podržavaLiSrednjeFrekvencije = false;
		new private const bool podržavaLiVisokeFrekvencije = false;

	}
}
