﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeriousGlazbenaLinija.Zvučnici {
	/// <summary>
	/// Sučelje koje predstavlja jedan zvučnik.
	/// </summary>
	public interface IZvučnik {
		/// <summary>
		/// Podržava li zvučnik niske frekvencije.
		/// </summary>
		bool podržavaNiskeFrekvencije();

		/// <summary>
		/// Podržava li zvučnik srednje frekvencije.
		/// </summary>
		bool podržavaSrednjeFrekvencije();

		/// <summary>
		/// Podržava li zvučnik visoke frekvencije.
		/// </summary>
		bool podržavaVisokeFrekvencije();
	}
}
