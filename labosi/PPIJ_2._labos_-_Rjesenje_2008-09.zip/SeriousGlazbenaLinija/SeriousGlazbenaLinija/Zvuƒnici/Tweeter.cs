﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeriousGlazbenaLinija.Zvučnici {
	/// <summary>
	/// Tweeter, zvučnik koji podržava samo visoke frekvencije.
	/// </summary>
	class Tweeter : Zvučnik {
		new private const bool podržavaLiNiskeFrekvencije = false;
		new private const bool podržavaLiSrednjeFrekvencije = false;
		new private const bool podržavaLiVisokeFrekvencije = true;

	}

}
