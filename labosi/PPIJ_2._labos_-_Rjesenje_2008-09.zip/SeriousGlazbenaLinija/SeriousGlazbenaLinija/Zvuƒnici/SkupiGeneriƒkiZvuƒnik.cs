﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeriousGlazbenaLinija.Zvučnici {
	/// <summary>
	/// Skupi generički zvučnik koji može reproducirati sve frekvencije.
	/// </summary>
	class SkupiGeneričkiZvučnik : Zvučnik {
		new private const bool podržavaLiNiskeFrekvencije = true;
		new private const bool podržavaLiSrednjeFrekvencije = true;
		new private const bool podržavaLiVisokeFrekvencije = true;

	}
}
