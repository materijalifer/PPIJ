﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeriousGlazbenaLinija.Komponente {
	public enum EKomponenta {
		RadioPrijemnik,
		Pojačalo,
		CDPlayer
	}
}
