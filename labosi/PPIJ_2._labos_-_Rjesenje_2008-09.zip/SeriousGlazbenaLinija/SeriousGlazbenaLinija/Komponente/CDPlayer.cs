﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeriousGlazbenaLinija.Komponente {
	class CDPlayer : Komponenta {
		private String imeKomponente = "CD player";

		/// <summary>
		/// Pritišće gumb na komponenti.
		/// </summary>
		/// <param name="gumb">gumb koji želimo pritisnuti</param>
		public override void pritisnutGumb(EGumb gumb) {

			// izvrši akciju
			switch (gumb) {
				case EGumb.Play:
					if (this.vratiStanje().Equals(Stanja.EStanje.Idle) ||
							this.vratiStanje().Equals(Stanja.EStanje.Paused)) {
						this.postaviStanje(Stanja.EStanje.Playing);
						Ispisi.Opći.ispiši("Play tipka pritisnuta; CD trenutno svira.");
					} else {
						Ispisi.GreškaGumb.ispiši(Ispisi.EGreškaGumb.NemogućaAkcija, imeKomponente);
					}
					break;
				case EGumb.Pause:
					if (this.vratiStanje().Equals(Stanja.EStanje.Playing)) {
						this.postaviStanje(Stanja.EStanje.Paused);
						Ispisi.Opći.ispiši("Pause tipka pritisnuta; svirka CD-a pauzirana.");
					} else {
						Ispisi.GreškaGumb.ispiši(Ispisi.EGreškaGumb.NemogućaAkcija, imeKomponente);
					}
					break;
				case EGumb.Stop:
					if (this.vratiStanje().Equals(Stanja.EStanje.Playing) ||
							this.vratiStanje().Equals(Stanja.EStanje.Paused)) {
						this.postaviStanje(Stanja.EStanje.Idle);
						Ispisi.Opći.ispiši("Stop tipka pritisnuta; svirka CD-a zaustavljena.");
					} else {
						Ispisi.GreškaGumb.ispiši(Ispisi.EGreškaGumb.NemogućaAkcija, imeKomponente);
					}

					break;
				case EGumb.Eject:
					if (this.vratiStanje().Equals(Stanja.EStanje.Ejected)) {
						Ispisi.Opći.ispiši("Eject tipka pritisnuta; ubacujem CD ..");
						this.postaviStanje(Stanja.EStanje.Loading);
						Ispisi.Opći.ispiši("Eject tipka pritisnuta; CD ubačen i spreman na svirku.");
						this.postaviStanje(Stanja.EStanje.Idle);
					} else {
						if (this.vratiStanje().Equals(Stanja.EStanje.Playing) ||
								this.vratiStanje().Equals(Stanja.EStanje.Paused) ||
								this.vratiStanje().Equals(Stanja.EStanje.Seeking)) {
							this.postaviStanje(Stanja.EStanje.Idle);
							Ispisi.Opći.ispiši("Eject tipka pritisnuta; zaustavljam CD ..");
						}
						Ispisi.Opći.ispiši("Eject tipka pritisnuta; izbacujem CD ..");
						this.postaviStanje(Stanja.EStanje.Ejecting);
						Ispisi.Opći.ispiši("Eject tipka pritisnuta; CD izbačen.");
						this.postaviStanje(Stanja.EStanje.Ejected);
					}
					break;
				default:
					Ispisi.GreškaGumb.ispiši(Ispisi.EGreškaGumb.AkcijaNijePodržana, imeKomponente);
					break;

			}


		}

	}
}
