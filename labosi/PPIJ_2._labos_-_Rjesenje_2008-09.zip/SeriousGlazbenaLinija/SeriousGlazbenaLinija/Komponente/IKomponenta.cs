﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeriousGlazbenaLinija.Komponente {
	public interface IKomponenta {

		/// <summary>
		/// Postavlja stanje napajanja - je li fizički struja dostupna ili nije.
		/// </summary>
		/// <param name="stanje">true ili false, ovisno o željenoj akciji</param>
		void postaviStanjeNapajanja(bool stanjeNapajanja);

		/// <summary>
		/// Vraća trenutno stanje komponente.
		/// </summary>
		/// <returns>trenutno stanje</returns>
		Stanja.EStanje vratiStanje();

		/// <summary>
		/// Postavlja ime komponente na zadanu vrijednost.
		/// </summary>
		/// <param name="imeKomponente">zadano ime</param>
		void postaviIme(String imeKomponente);

		/// <summary>
		/// Vraća ime komponente.
		/// </summary>
		/// <returns>ime komponente</returns>
		String vratiIme();

		/// <summary>
		/// Pritišće gumb na komponenti.
		/// </summary>
		/// <param name="gumb">gumb koji želimo pritisnuti</param>
		void pritisniGumb(EGumb gumb);

		/// <summary>
		/// Postavlja glasnoću komponente na zadanu razinu.
		/// </summary>
		/// <param name="glasnoća">tražena glasnoća</param>
		void postaviGlasnoću(float glasnoća);

		/// <summary>
		/// Vraća trenutnu razinu glasnoće.
		/// </summary>
		/// <returns>trenutna razina glasnoće</returns>
		float vratiGlasnoću();

		/// <summary>
		/// Postavlja mute status ove komponente.
		/// </summary>
		/// <param name="glasnoća">traženi mute status</param>
		void postaviMute(bool mute);

		/// <summary>
		/// Vraća mute status ove komponente.
		/// </summary>
		/// <returns>mute status</returns>
		bool vratiMute();


	}
}
