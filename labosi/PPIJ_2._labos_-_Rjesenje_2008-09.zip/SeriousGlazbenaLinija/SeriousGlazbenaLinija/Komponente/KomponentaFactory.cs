﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeriousGlazbenaLinija.Komponente {
	/// <summary>
	/// Omogućuje izradu novih objekata klase koja implementira
	/// <see cref="IKomponenta"/> sučelje.
	/// Oblikovni obrazac: Factory
	/// </summary>
	public static class KomponentaFactory {

		public static IKomponenta napraviKomponentu(EKomponenta tipKomponente) {
			switch (tipKomponente) {
				case EKomponenta.Pojačalo:
					return new Pojačalo();
				case EKomponenta.RadioPrijemnik:
					return new RadioPrijemnik();
				case EKomponenta.CDPlayer:
					return new CDPlayer();
				default:
					throw new Exceptioni.NepostojećiTipKomponenteException();
			}
		}

	}
}
