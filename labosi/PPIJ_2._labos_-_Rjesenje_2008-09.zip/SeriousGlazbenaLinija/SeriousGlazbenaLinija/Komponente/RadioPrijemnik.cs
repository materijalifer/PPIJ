﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeriousGlazbenaLinija.Komponente {
	class RadioPrijemnik : Komponenta {
		const String imeKomponente = "Radio prijemnik";

		/// <summary>
		/// Pritišće gumb na komponenti.
		/// </summary>
		/// <param name="gumb">gumb koji želimo pritisnuti</param>
		public override void pritisnutGumb(EGumb gumb) {
			
			// izvrši akciju
			switch (gumb) {
				case EGumb.OnOff:
					// ukoliko smo se upravo uključili, počni slati zvuk
					if (this.vratiStanje().Equals(Stanja.EStanje.Idle)) {
						this.postaviStanje(Stanja.EStanje.Playing);
					}
					break;
				default:
					Ispisi.GreškaGumb.ispiši(Ispisi.EGreškaGumb.AkcijaNijePodržana, imeKomponente);
					break;

			}


		}

	}
}
