﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeriousGlazbenaLinija.Komponente {
	public abstract class Komponenta : IKomponenta {
		/// Komponenta je nakon inicijalizacije u StandBy stanju, tj. isključena je.
		private const Stanja.EStanje POČETNO_STANJE_KOMPONENTE = Stanja.EStanje.StandBy;
		private bool stanjeNapajanja;
		private Stanja.Stanje stanje = null;
		private String imeKomponente;
		private float glasnoća;
		private bool mute;


		/// <summary>
		/// Inicijalizira ovu komponentu sa definiranim početnim stanjem.
		/// </summary>
		public Komponenta() {
			stanje = new Stanja.Stanje(POČETNO_STANJE_KOMPONENTE);
		}

		/// <summary>
		/// Uključuje ili isključuje ovu komponentu od glavne komponente.
		/// </summary>
		/// <param name="stanje">true ili false, ovisno o željenoj akciji</param>
		public void postaviStanjeNapajanja(bool stanjeNapajanja) {
			this.stanjeNapajanja = stanjeNapajanja;
		}
		/// <summary>
		/// Vraća stanje napajanja ove komponente, tj. je li komponenta spojena sa glavnom.
		/// </summary>
		/// <returns>stanje napajanja</returns>
		public bool vratiStanjeNapajanja() {
			return stanjeNapajanja;
		}


		/// <summary>
		/// Vraća trenutno stanje komponente.
		/// </summary>
		/// <returns>trenutno stanje</returns>
		public Stanja.EStanje vratiStanje() {
			return this.stanje.trenutnoStanje();
		}

		/// <summary>
		/// Postavlja trenutno stanje ove komponente na zadano.
		/// </summary>
		/// <param name="stanje">zadano novo stanje</param>
		protected void postaviStanje(Stanja.EStanje novoStanje) {
			this.stanje.novoStanje(novoStanje);
		}

		/// <summary>
		/// Postavlja ime ove komponente na zadanu vrijednost.
		/// </summary>
		/// <param name="imeKomponente">zadano ime</param>
		public void postaviIme(String imeKomponente) {
			this.imeKomponente = imeKomponente;
		}

		/// <summary>
		/// Vraća ime ove komponente.
		/// </summary>
		/// <returns>ime komponente</returns>
		public String vratiIme() {
			return this.imeKomponente;
		}

		/// <summary>
		/// Pritišće gumb na komponenti.
		/// </summary>
		/// <param name="gumb">gumb koji želimo pritisnuti</param>
		public void pritisniGumb(EGumb gumb) {
			// provjeri imamo li električne energije
			if (stanjeNapajanja == false) {
				Ispisi.GreškaGumb.ispiši(Ispisi.EGreškaGumb.NemaEnergije, imeKomponente);
				return;
			}

			// provjeri jesmo li isključeni (tada reagira samo gumb on/off)
			if (stanje.trenutnoStanje().Equals(Stanja.EStanje.StandBy)) {
				if (gumb != EGumb.OnOff) {
					Ispisi.GreškaGumb.ispiši(Ispisi.EGreškaGumb.KomponentaUgašena, imeKomponente);
					return;
				}
			}

			// izvrši standardne akcije
			switch (gumb) {
				case EGumb.OnOff:
					if (this.vratiStanje().Equals(Stanja.EStanje.StandBy)) {
						this.postaviStanje(Stanja.EStanje.Idle);
						Ispisi.Opći.ispiši("On/Off tipka pritisnuta; komponenta [" + this.vratiIme() + "] upaljena.");
					} else {
						this.postaviStanje(Stanja.EStanje.StandBy);
						Ispisi.Opći.ispiši("On/Off tipka pritisnuta; komponenta [" + this.vratiIme() + "] ugašena.");
					}
					break;
				case EGumb.Mute:
					this.postaviMute(!this.vratiMute());
					Ispisi.Opći.ispiši("Mute tipka pritisnuta; mute stanje: [" + this.vratiMute() + "].");
					break;
				default:
					// akcija je možda implementirana u specifičnoj klasi
					this.pritisnutGumb(gumb);
					break;

			}
		}

		/// <summary>
		/// Omogućuje specifičnoj implementaciji komponente da izvrši svoje akcije.
		/// </summary>
		/// <param name="gumb">gumb koji smo pritisnuli</param>

		public abstract void pritisnutGumb(EGumb gumb);

		/// <summary>
		/// Postavlja glasnoću ove komponente na zadanu razinu.
		/// </summary>
		/// <param name="glasnoća">tražena glasnoća</param>
		public void postaviGlasnoću(float glasnoća) {
			this.glasnoća = glasnoća;
		}
		/// <summary>
		/// Vraća trenutnu razinu glasnoće ove komponente.
		/// </summary>
		/// <returns>trenutna razina glasnoće</returns>
		public float vratiGlasnoću() {
			return this.glasnoća;
		}

		/// <summary>
		/// Postavlja mute status ove komponente.
		/// </summary>
		/// <param name="glasnoća">traženi mute status</param>
		public void postaviMute(bool mute) {
			this.mute = mute;
		}
		/// <summary>
		/// Vraća mute status ove komponente.
		/// </summary>
		/// <returns>mute status</returns>
		public bool vratiMute() {
			return this.mute;
		}


	}
}
