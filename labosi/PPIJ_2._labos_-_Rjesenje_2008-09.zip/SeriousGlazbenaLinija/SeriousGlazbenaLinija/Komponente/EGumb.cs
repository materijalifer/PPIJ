﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeriousGlazbenaLinija.Komponente {
	/// <summary>
	/// Popis gumbiju koji postoje na bilo kojoj komponenti.
	/// </summary>
	public enum EGumb {
		OnOff,
		Play,
		Pause,
		Stop,
		Record,
		Next,
		Previous,
		Mute,
		Eject
	}
}
