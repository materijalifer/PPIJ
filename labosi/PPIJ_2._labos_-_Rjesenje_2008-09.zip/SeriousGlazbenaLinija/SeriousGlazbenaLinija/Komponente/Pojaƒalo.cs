﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeriousGlazbenaLinija.Komponente {
	class Pojačalo : Komponenta {
		private float glasnoćaNiskogPodručja;
		private float glasnoćaSrednjegPodručja;
		private float glasnoćaVisokogPodručja;

		private List<Zvučnici.IZvučnik> zvučnici;

		/// <summary>
		/// Inicijalizira ovo pojačalo.
		/// </summary>
		public Pojačalo() {
			this.zvučnici = new List<Zvučnici.IZvučnik>();

		}

		/// <summary>
		/// Komponenta nema nikakve dodatne gumbe.
		/// </summary>
		/// <param name="gumb">gumb koji je pritisnut</param>
		public override void pritisnutGumb(EGumb gumb) {
			return;
		}

		#region spajanje i odspajanje zvučnika
		/// <summary>
		/// Pokuša spojiti zadani zvučnik na pojačalo.
		/// </summary>
		/// <param name="zvučnik">true ako je spajanje uspjelo</param>
		/// <returns></returns>
		public bool spojiZvučnik(Zvučnici.IZvučnik zvučnik) {
			// odbij spajanje zvučnika ukoliko isti ne postoji ili je već spojen
			if (zvučnik == null || zvučnici.Contains(zvučnik)) {
				return false;
			}
			zvučnici.Add(zvučnik);
			Ispisi.Opći.ispiši("Pojačalo-> Zvučnik tipa [" + zvučnik.GetType() + "] spojen na pojačalo.");
			return true;
		}

		public bool odspojiZvučnik(Zvučnici.IZvučnik zvučnik) {
			// odbij odspajanje zvučnika ukoliko isti ne postoji ili nije spojen
			if (zvučnik == null || !zvučnici.Contains(zvučnik)) {
				return false;
			}
			zvučnici.Remove(zvučnik);
			Ispisi.Opći.ispiši("Pojačalo-> Zvučnik tipa [" + zvučnik.GetType() + "] odspojen sa pojačala.");
			return true;
		}
		#endregion


	}
}
