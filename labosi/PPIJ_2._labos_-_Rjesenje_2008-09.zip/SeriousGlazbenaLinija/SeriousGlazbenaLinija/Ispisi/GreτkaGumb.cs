﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeriousGlazbenaLinija.Ispisi {
	public static class GreškaGumb {
		
		public static void ispiši(EGreškaGumb tipGreške, String nazivKomponente) {
			switch (tipGreške) {
				case EGreškaGumb.NemaEnergije:
					Console.WriteLine("Pritisnut je gumb dok je komponenta [" + nazivKomponente + "] odspojena.");
					break;
				case EGreškaGumb.KomponentaUgašena:
					Console.WriteLine("Pritisnut je gumb dok je komponenta [" + nazivKomponente + "] ugašena.");
					break;
				case EGreškaGumb.NemogućaAkcija:
					Console.WriteLine("Nije moguće trenutno izvršiti zadanu akciju za komponentu [" + nazivKomponente + "].");
					break;
				case EGreškaGumb.AkcijaNijePodržana:
					Console.WriteLine("Akcija nije podržana za komponentu [" + nazivKomponente + "].");
					break;
			}
		}
	}
}
