﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeriousGlazbenaLinija.Ispisi {
	public static class Greška {
		/// <summary>
		/// Ispisuje zadani tekst greške.
		/// </summary>
		/// <param name="tekst">tekst koji će se ispisati</param>
		public static void ispiši(String tekst) {
			Console.WriteLine(tekst);
		}
	}
}
