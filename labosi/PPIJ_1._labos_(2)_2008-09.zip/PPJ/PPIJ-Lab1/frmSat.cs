﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PPIJ_Lab1 {
    public partial class frmSat : Form {
        private const float DEBLJINA_LINIJE = 3f;

        public frmSat() {
            InitializeComponent();
        }

        private void frmSat_Load( object sender, EventArgs e ) {
            //inicijalizacija timera i geometrije sata
        }

        private void frmSat_Paint( object sender, PaintEventArgs e ) {
            //iscrtavanje sata, pokreće se svaki put kad se forma
            //ponovo oslikava na ekranu
            //this.ctrlSat1.Refresh();
        }

        private void ProbnoCrtanje() {
            
        }
    }
}
