﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Timers;

namespace PPIJ_Lab1
{
    /// <summary>
    /// Implementacija samog sata.
    /// </summary>
    public class Sat
    {
        public const int MAKS_SEKUNDE = 60;
        public const int MAKS_MINUTE = 60;
        public const int MAKS_SATI = 12;
   
        private int minute=0;
        public int Minute
        {
            get { return minute; }
        }
        private int sekunde=0;
        public int Sekunde
        {
            get { return sekunde; }
        }
        private int sati=0;
        public int Sati
        {
            get { return sati; }
        }
        
        private Timer timerSata = new Timer();
        private int JEDNA_SEKUNDA = 1000;
        
        public Sat()
        {
            timerSata.Interval = JEDNA_SEKUNDA;
            timerSata.Elapsed += new ElapsedEventHandler(timerSata_Elapsed);
            timerSata.Start();
        }

        void timerSata_Elapsed(object sender, ElapsedEventArgs e)
        {
            osvjezi();
        }
        private void osvjezi()
        {
            DateTime datumSada = DateTime.Now;
            this.sekunde = datumSada.Second;
            this.minute = datumSada.Minute;
            this.sati = datumSada.Hour;
        }

    }
}
