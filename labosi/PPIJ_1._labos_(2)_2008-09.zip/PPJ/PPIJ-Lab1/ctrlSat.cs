﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PPIJ_Lab1
{
    public partial class ctrlSat : UserControl
    {
        private SatIzgled satIzgled = new SatIzgled();

        /// <summary>
        /// Definira izgled sata
        /// </summary>
        public SatIzgled SatIzgled
        {
            get
            {
                return satIzgled;
            }

        }

        private const int TIMER_INTERVAL = 1000;

        /* konstante za opis izgleda sata */
        private const int DULJINA_KAZALJKA_SAT = 40;
        private const int DULJINA_KAZALJKA_MINUTA = 60;
        private const int DULJINA_KAZALJKA_SEKUNDA = 80;

        private const int SREDISTE_SAT_APSCISA = 150;
        private const int SREDISTE_SAT_ORDINATA = 150;

        private const int DULJINA_VISINA_SATA = 150;
        
        private Timer timerSata = new Timer();
        private Sat sat = new Sat();
        private Graphics graphicContext;

        public ctrlSat()
        {
            InitializeComponent();
            pokreniKomponente();
        }

        private void pokreniKomponente()
        {
            this.timerSata.Interval = TIMER_INTERVAL;
            this.timerSata.Tick += new EventHandler(timerZaIscrtavanje_Tick);
            this.timerSata.Start();
            graphicContext = this.CreateGraphics();
        }

        private void timerZaIscrtavanje_Tick(object sender, EventArgs e)
        {
            IscrtajSat();
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            IscrtajSat();
            
            
        }
        protected void IscrtajSat()
        {
            //graphicContext.Clear(Color.White);
            
            if (!DesignMode)
            {
                graphicContext.Clear(Color.White);
                iscrtajOkvir();
                iscrtajSekunde();
                iscrtajMinute();
                iscrtajSate();
                graphicContext.Flush();
            }
        }
        private void iscrtajOkvir()
        {
            int n=5;

            Point centar = new Point(SREDISTE_SAT_APSCISA, SREDISTE_SAT_ORDINATA);

            for (int i = 0; i < n; i++)
            {

                int h = i*15;
                Point novaTocka = new Point(centar.X - h, centar.Y - h); 
                Rectangle rectPravokutnik = new Rectangle(novaTocka, new Size(h*2, h*2));
                Pen penPravokutnik=new Pen(Color.Red);
                graphicContext.DrawRectangle(penPravokutnik, rectPravokutnik);
            }

            int d = 165;
            Rectangle rectElipse = new Rectangle(centar.X-d/2, centar.Y-d/2, d, d);
            Pen rectPen=new Pen(Color.Blue);
            graphicContext.DrawEllipse(rectPen, rectElipse);
        }

        private void iscrtajSekunde()
        {
            Point tocka = IzracunajTocku(DULJINA_KAZALJKA_SEKUNDA, sat.Sekunde, Sat.MAKS_SEKUNDE);
            IscrtajTocku(tocka, SatIzgled.KazaljkaSekunda);
        }
        private void iscrtajMinute()
        {
            Point tocka = IzracunajTocku(DULJINA_KAZALJKA_MINUTA, sat.Minute, Sat.MAKS_MINUTE);
            IscrtajTocku(tocka, SatIzgled.KazaljkaMinuta);
        }
        private void iscrtajSate()
        {
            Point tocka = IzracunajTocku(DULJINA_KAZALJKA_SAT, sat.Sati, Sat.MAKS_SATI);
            IscrtajTocku(tocka, SatIzgled.KazaljkaSat);
        }
        protected virtual Point IzracunajTocku(int duljinaKazaljke, int vrijednostKazaljke, int maksVrijednostKazaljke)
        {
            Point rezultat = new Point();
            const int PUNI_KRUG=360;
            const int POLA_KRUGA=PUNI_KRUG/2;

            double cos=Math.Cos(Math.PI / 2 - (vrijednostKazaljke * (PUNI_KRUG/maksVrijednostKazaljke) * Math.PI)/POLA_KRUGA);
            double sin=Math.Sin(Math.PI/2 -(vrijednostKazaljke * (PUNI_KRUG/maksVrijednostKazaljke)*Math.PI)/POLA_KRUGA);

            rezultat.X = (int)Math.Round(DULJINA_VISINA_SATA + duljinaKazaljke * cos);
            rezultat.Y = (int)Math.Round(DULJINA_VISINA_SATA - duljinaKazaljke * sin);
            return rezultat;
        }
        protected virtual void IscrtajTocku(Point tocka, Pen olovka)
        {
            Point centar=new Point(SREDISTE_SAT_APSCISA, SREDISTE_SAT_ORDINATA);
            this.graphicContext.DrawLine(olovka, centar, tocka);

        }
    }
    public class SatIzgled
    {
        public Pen KazaljkaSat { get; set; }
        public Pen KazaljkaMinuta { get; set; }
        public Pen KazaljkaSekunda { get; set; }

        public SatIzgled()
        {
            this.KazaljkaMinuta = new Pen(Color.Black, 3);
            this.KazaljkaSekunda = new Pen(Color.Gray, 1);
            this.KazaljkaSat = new Pen(Color.Black, 5);
        }
    }
}
